#!/bin/bash

source kp.conf
source $MODULES_PATH/misc_module.sh
source $TOP10_PATH/3_kp_crackmapexec.sh
source $TOP10_PATH/6_kp_metasploit.sh
source $TOOL_PATH/31_kp_setoolkit.sh

function menu_attack(){
    clear
    figlet Attack
    num3 0 "Attack"
    num1 5 "Metasploit"
    num2 5 "Social-Engineering" "(setoolkit)"
    num3 5 "Brute-force" "(crackmapexec)"
    num9 5 "Main"
    read -n 1 -s NUM
    case $NUM in
    1)
        menu_metasploit
        ;;
    2)
        menu_setoolkit
        ;;
    3)
        menu_crackmapexec
        ;;
    9)
        mainmenu
        ;;
    *)
        ;;
    esac

}